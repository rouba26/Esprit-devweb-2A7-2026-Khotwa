-- Create a database named `session` first (or change the name in config/database.php)
-- CREATE DATABASE session CHARACTER SET utf8mb4;
-- USE session;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- To make an admin: register normally, then run (workshop 6.4):
-- UPDATE users SET role = 'admin' WHERE email = 'you@example.com';

-- XSS test account (workshop 7.3) - password: User@1234
-- INSERT INTO users (username, email, password, role) VALUES
-- ('<script>alert(''test'')</script>', 'xsstest@example.com',
--  '$2y$10$B9OJgl/Y9A05dLd4TYZtsuZ2.qLbFcnJYdxLHcije9.Z/hhkDxkcq', 'user');
